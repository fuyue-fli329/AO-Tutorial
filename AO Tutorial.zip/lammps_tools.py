import subprocess 
import shlex

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import lammps.formats as lmpf
import ovito.io as io
from ovito.modifiers import ExpressionSelectionModifier as ESM
from ovito.modifiers import InvertSelectionModifier as ISM
from ovito.modifiers import DeleteSelectedModifier as DSM
from ovito.modifiers import ComputePropertyModifier as CPM

import re


################################################################################################################

def ReadLog(filename: str = 'log.lmp', num: int = 1, step: int = 1, units: str = 'real', multiple: bool = False):
    """
    Read log file and return a pandas DataFrame

    Parameters
        `file` (str): log filename

        `num` (int): number of steps to average
        
        `step` (int): step size for reading log file
        
        `units` (str): units of simulation

    Returns
        `log` (DataFrame): pandas DataFrame with averaged log data
    """
    file = lmpf.LogFile(filename)
    if multiple:
        dict = file.runs[0]
        for i in range(1, len(file.runs)):
            current_dict = file.runs[i]
            for key, value in current_dict.items():
                for val in value:
                    dict[key].append(val)
        log = pd.DataFrame(dict)
        
    else:
        log = pd.DataFrame(file.runs[0])
    
    log.drop_duplicates(subset='Step', keep='first', inplace=True, ignore_index=True)
    
    if num > 1:
        df0 = log.iloc[:1]
        df1 = log.iloc[1:].reset_index(drop=True)

        # Group by every num steps, calculate the mean, and keep the first row
        grouped = df1.groupby(df1.index // num)
        agg_dict = {col: ('last' if (col == 'Step' or col == 'Time') else 'mean') for col in df1.columns}
        df1 = grouped.agg(agg_dict).reset_index(drop=True)

        # Concatenate the first row with the grouped DataFrame
        log = pd.concat([df0, df1]).reset_index(drop=True)
    
    # skip every step
    if step > 1:
        log = log.iloc[::step].reset_index(drop=True)

    if units == 'real':
        log['Time'] *= 0.001    # ps
        log['Time'] = round(log['Time'], 2)
    
    return log
    
################################################################################################################

def ReadDump(filename: str = 'dump.lmp', dump = 0.2, step: int = 1, slab_above: float = 5, num_frames: int = None, frames: list = None, dt: float = 0.1, AO: bool = True, spe: bool = True):
    """
    Read dump file for thermo and write species file

    Parameters
        `filename` (str): dump file name
        
        `dump` (float): dump interval (ps)

        `step` (int): step size for reading dump file
        
        `slab_above` (float): slab distance above the surface (Å)

        `num_frames` (int): number of frames to read
        
        `dt` (float): time step (fs)
        
        `AO` (bool): whether to include No. of AO in the log file

    Returns
        `log` (DataFrame): log thermo output
    """
    pipeline = io.import_file(filename)
    if num_frames is None:
        num_frames = pipeline.source.num_frames
    
    if (num_frames-1) % step != 0:
        print(f'Warning: {num_frames-1} frames are not divisible by {step}')
        return
    if frames is None:
        index = np.arange(0, num_frames, step)
    else:
        index = np.array(frames)

    end = max(index)
    # create an empty numpy array
    dict = {}

    if spe:
        f1 = open('all.all.spe', 'w')
        f11 = open('vacuum.all.spe', 'w')
    
    for i in index:
        # Run 'in.lmp'
        command_line = f'lmp -in in.lmp -var dump {dump} -var n {i} -var num {end-i} -var dumpfile {filename} -var slab_above {slab_above} -var dt {dt} -log log.lmp'
        args = shlex.split(command_line)
        p = subprocess.Popen(args)
        p.wait()

        # Read 'log.lmp'
        file = lmpf.LogFile('log.lmp')
        Log = file.runs[0]
        for key in Log.keys():
            if key not in dict:
                dict[key] = []
            dict[key].append(Log[key][0])
        
        # Read 'all.spe'
        # Write 'all.all.spe'
        try:
            with open('all.spe') as f2:
                lines = f2.readlines()
            for line in lines:
                if 'Timestep' in line:
                    pass
                else:
                    temp = line.split()
                    old = temp[0]
                    new = str(int(old) - 1)
                    temp[0] = new
                    line = '\t'.join(temp)
                f1.write(line)
            f1.write('\n')
        except FileNotFoundError:
            pass
        
        # Read 'vaccuum.spe'
        # Write 'vacuum.all.spe'
        try:
            with open('vacuum.spe') as f22:
                lines = f22.readlines()
            for line in lines:
                if 'Timestep' in line:
                    pass
                else:
                    temp = line.split()
                    old = temp[0]
                    new = str(int(old) - 1)
                    temp[0] = new
                    line = '\t'.join(temp)
                f11.write(line)
            f11.write('\n')
        except FileNotFoundError:
            pass
    
    if spe:
        f1.close()
        f11.close()

    log = pd.DataFrame(dict) 
    log['Time'] = log['Step'] * dt / 1000   # ps
    log = log[['Time'] + [col for col in log.columns if col != 'Time']]
    log = log[['Step'] + [col for col in log.columns if col != 'Step']]
    
    if AO:
        log['AO'] = log.index
    log.to_csv('log.csv', index=False)
    
################################################################################################################

def ReadDumpDt(filename: str = 'AO.dump', slab_above: float = 5, AO: bool = True, num: int = 1, dt: float = 0.1, time: bool = True, num_frames: int = None):
    """
    Read dump file for thermo and write species file

    Parameters
        `filename` (str): dump file name
        
        `slab_above` (float): slab distance above the surface (Å)
        
        `AO` (bool): whether to include No. of AO in the log file
        
        `num` (int): number of steps to load log file

    Returns
        `log` (DataFrame): log thermo output
    """
    pipeline = io.import_file(location=filename, input_format='lammps/dump')
    if num_frames is None:
        num_frames = pipeline.source.num_frames
    nsteps = []
    times = []
    for frame in range(num_frames):
        data = pipeline.compute(frame)
        nsteps.append(data.attributes['Timestep'])
        if time:
            times.append(round(data.attributes['Time']/1000, 1))
        else:
            times.append(data.attributes['Timestep']/1000*dt)
    df = pd.DataFrame({'Timestep': nsteps, 'Time': times})
    df.drop_duplicates(subset='Time', keep='last', inplace=True, ignore_index=True)
    nsteps = df['Timestep']
    times = df['Time']

    # create an empty numpy array
    dict = {}

    f1 = open('all.all.spe', 'w')
    f11 = open('vacuum.all.spe', 'w')
    
    for i in nsteps:
        # Run 'in.lmp'
        command_line = f'lmp -in in.lmp -var nstep {i} -var dumpfile {filename} -var slab_above {slab_above} -log log.lmp'
        args = shlex.split(command_line)
        p = subprocess.Popen(args)
        p.wait()

        # Read 'log.lmp'
        file = lmpf.LogFile('log.lmp')
        Log = file.runs[0]
        for key in Log.keys():
            if key not in dict:
                dict[key] = []
            dict[key].append(Log[key][0])
        
        # Read 'all.spe'
        # Write 'all.all.spe'
        try:
            with open('all.spe') as f2:
                lines = f2.readlines()
            for line in lines:
                if 'Timestep' in line:
                    pass
                else:
                    temp = line.split()
                    old = temp[0]
                    new = str(int(old) - 1)
                    temp[0] = new
                    line = '\t'.join(temp)
                f1.write(line)
            f1.write('\n')
        except FileNotFoundError:
            pass
        
        # Read 'vacuum.spe'
        # Write 'vacuum.all.spe'
        try:
            with open('vacuum.spe') as f22:
                lines = f22.readlines()
            for line in lines:
                if 'Timestep' in line:
                    pass
                else:
                    temp = line.split()
                    old = temp[0]
                    new = str(int(old) - 1)
                    temp[0] = new
                    line = '\t'.join(temp)
                f11.write(line)
            f11.write('\n')
        except FileNotFoundError:
            pass
    
    f1.close()
    f11.close()

    log = pd.DataFrame(dict) 
    log['Time'] = times
    log = log[['Time'] + [col for col in log.columns if col != 'Time']]
    log = log[['Step'] + [col for col in log.columns if col != 'Step']]
    
    if num > 1:
        log = log.iloc[::num].reset_index(drop=True)
    if AO:
        log['AO'] = log.index
    log.to_csv('log.csv', index=False)

################################################################################################################

def ReadReadDump(filename: str = 'slab.dump', filename2: str = 'vacuum.dump', dump = 1, step: int = 1, slab_above: float = 15, num_frames: int = None, frames: list = None, dt: float = 0.5, AO: bool = True, num: int = 2):
    """
    Read dump file for thermo and write species file

    Parameters
        `filename` (str): dump file name
        
        `dump` (float): dump interval (ps)

        `step` (int): step size for reading dump file
        
        `slab_above` (float): slab distance above the surface (Å)

        `num_frames` (int): number of frames to read
        
        `dt` (float): time step (fs)
        
        `AO` (bool): whether to include No. of AO in the log file
        
        `num` (int): number of steps to load log file

    Returns
        `log` (DataFrame): log thermo output
    """
    pipeline = io.import_file(filename)
    if num_frames is None:
        num_frames = pipeline.source.num_frames
    
    if (num_frames-1) % step != 0:
        print(f'Warning: {num_frames-1} frames are not divisible by {step}')
        return
    if frames is None:
        index = np.arange(0, num_frames, step)
    else:
        index = np.array(frames)

    end = max(index)
    # create an empty numpy array
    dict = {}

    f1 = open('slab.all.spe', 'w')
    f11 = open('vacuum.all.spe', 'w')
    
    for i in index:
        # Run 'in.lmp'
        command_line = f'lmp -in in.lmp -var dump {dump} -var n {i} -var num {end-i} -var dumpfile {filename} -var slab_above {slab_above} -var dt {dt} -log log.lmp'
        args = shlex.split(command_line)
        p = subprocess.Popen(args)
        p.wait()
        
        # Run 'in.vacuum.lmp'
        command_line = f'lmp -in in.vacuum.lmp -var dump {dump} -var n {i} -var num {end-i} -var dumpfile {filename2} -var slab_above {slab_above} -var dt {dt} -log log.vacuum.lmp'
        args = shlex.split(command_line)
        p = subprocess.Popen(args)
        p.wait()

        # Read 'log.lmp'
        file = lmpf.LogFile('log.lmp')
        Log = file.runs[0]
        for key in Log.keys():
            if key not in dict:
                dict[key] = []
            dict[key].append(Log[key][0])
        
        # Read 'slab.spe'
        # Write 'slab.all.spe'
        try:
            with open('slab.spe') as f2:
                lines = f2.readlines()
            for line in lines:
                if 'Timestep' in line:
                    pass
                else:
                    temp = line.split()
                    old = temp[0]
                    new = str(int(old) - 1)
                    temp[0] = new
                    line = '\t'.join(temp)
                f1.write(line)
            f1.write('\n')
        except FileNotFoundError:
            pass
        
        # Read 'vacuum.spe'
        # Write 'vacuum.all.spe'
        try:
            with open('vacuum.spe') as f22:
                lines = f22.readlines()
            for line in lines:
                if 'Timestep' in line:
                    pass
                else:
                    temp = line.split()
                    old = temp[0]
                    new = str(int(old) - 1)
                    temp[0] = new
                    line = '\t'.join(temp)
                f11.write(line)
            f11.write('\n')
        except FileNotFoundError:
            pass
    
    f1.close()
    f11.close()

    log = pd.DataFrame(dict) 
    log['Time'] = log['Step'] * dt / 1000   # ps
    log = log[['Time'] + [col for col in log.columns if col != 'Time']]
    log = log[['Step'] + [col for col in log.columns if col != 'Step']]
    
    if num > 1:
        log = log.iloc[::num].reset_index(drop=True)
    if AO:
        log['AO'] = log.index
    log.to_csv('log.csv', index=False)

################################################################################################################

def plot_linear_density(filename: str = 'dump.lmp', dt: float = 0.1, frames: list = None, select: str = None, delete: bool = False, invert: bool = False, bins: int = 20, zhi: float = None):
    """
    Read dump file for linear density in z direction

    Parameters
        `file` (str): dump file name
        
        `dt` (float): time step (fs)
        
        `frames` (list): list of frames to plot

        `select` (str): selection expression

        `delete` (bool): delete selection
        
        `invert` (bool): invert selection
        
        `bins` (int): number of bins
        
        `zhi` (float): upper limit of z

    Returns
    """
    def LinearDensityModifier(frame, data, bins=bins, zhi=zhi):
        # Load position and mass
        xlo, lx, ylo, ly, zlo, lz = data.cell[0, 3], data.cell[0, 0], data.cell[1, 3], data.cell[1, 1], data.cell[2, 3], data.cell[2, 2]
        position = data.particles['Position']
        mass = data.particles['Mass']
        x, y, z = position[:, 0]-xlo, position[:, 1]-ylo, position[:, 2]-zlo
        area = lx * ly
        if zhi is None:
            zhi = lz
        # Convert atomic mass units per cubic Angstrom to grams per cubic centimeter
        amu_to_g = 1.66054
        # Compute linear density
        hist_mass, bin_edges = np.histogram(z, bins=bins, range=(0, zhi), weights=mass)
        bin_widths = np.diff(bin_edges)
        bin_centers = bin_edges[:-1]
        linear_density = hist_mass / (bin_widths * area) * amu_to_g
        data.attributes['Linear Density'] = [bin_centers, linear_density]
    
    pipeline = io.import_file(filename)
    if select is not None:
        pipeline.modifiers.append(ESM(expression = select))
    if invert:
        pipeline.modifiers.append(ISM())
    if delete:
        pipeline.modifiers.append(DSM())
    pipeline.modifiers.append(LinearDensityModifier)
    num_frames = pipeline.source.num_frames
    if frames is None:
        frames = [0, num_frames-1]

    for i in frames:
        data = pipeline.compute(i)
        time = data.attributes['Timestep'] * dt * 1e-3   # ps
        z = data.attributes['Linear Density'][0]
        linear_density = data.attributes['Linear Density'][1]
        #plt.plot(z, linear_density, label=f'{time:.2f} ps')
    #plt.xlabel('Z coordinate (Å)')
    #plt.ylabel(r'Density (g/cm$^3$)')
    #plt.legend()
    #plt.show()

    return z, linear_density, time

################################################################################################################

def plot_number_density(filename: str = 'dump.lmp', dt: float = 0.1, frames: list = None, select: str = None, delete: bool = False, invert: bool = False, bins: int = 20, zhi: float = None):
    """
    Read dump file for linear density in z direction

    Parameters
        `file` (str): dump file name
        
        `dt` (float): time step (fs)
        
        `frames` (list): list of frames to plot
        
        `select` (str): selection expression

        `delete` (bool): delete selection
        
        `invert` (bool): invert selection
        
        `bins` (int): number of bins
        
        `zhi` (float): upper limit of z

    Returns
    """
    def NumberDensityModifier(frame, data, bins=bins, zhi=zhi):
        # Load position and mass
        xlo, lx, ylo, ly, zlo, lz = data.cell[0, 3], data.cell[0, 0], data.cell[1, 3], data.cell[1, 1], data.cell[2, 3], data.cell[2, 2]
        position = data.particles['Position']
        mass = data.particles['Mass']
        x, y, z = position[:, 0]-xlo, position[:, 1]-ylo, position[:, 2]-zlo
        area = lx * ly
        if zhi is None:
            zhi = lz
        # Compute number density
        hist_count, bin_edges = np.histogram(z, bins=bins, range=(0, zhi))
        bin_widths = np.diff(bin_edges)
        bin_centers = bin_edges[:-1]
        number_density = hist_count / (bin_widths * area)
        data.attributes['Number Density'] = [bin_centers, number_density]
    
    pipeline = io.import_file(filename)
    if select is not None:
        pipeline.modifiers.append(ESM(expression = select))
    if invert:
        pipeline.modifiers.append(ISM())
    if delete:
        pipeline.modifiers.append(DSM())
    pipeline.modifiers.append(NumberDensityModifier)
    num_frames = pipeline.source.num_frames
    if frames is None:
        frames = [0, num_frames-1]

    for i in frames:
        data = pipeline.compute(i)
        time = data.attributes['Timestep'] * dt * 1e-3   # ps
        z = data.attributes['Number Density'][0]
        linear_density = data.attributes['Number Density'][1]
        #plt.plot(z, linear_density, label=f'{time:.2f} ps')
    #plt.xlabel('Z coordinate (Å)')
    #plt.ylabel(r'Number density (#/cm$^3$)')
    #plt.legend()
    #plt.show()

    return z, linear_density, time

################################################################################################################

def plot_linear_temp(filename: str = 'dump.lmp', dt: float = 0.1, frames: list = None, select: str = None, delete: bool = False, invert: bool = False, bins: int = 20, zhi: float = None, units: str = 'real'):
    """
    Read dump file for linear temperature in z direction

    Parameters
        `file` (str): dump file name
        
        `dt` (float): time step (fs)
        
        `frames` (list): list of frames to plot
        
        `select` (str): selection expression

        `delete` (bool): delete selection
        
        `invert` (bool): invert selection
        
        `bins` (int): number of bins
        
        `zhi` (float): upper limit of z

        `units` (str): units of simulation

    Returns
    """
    def LinearTempModifier(frame, data, bins=bins, zhi=zhi):
        # Load position and mass
        xlo, lx, ylo, ly, zlo, lz = data.cell[0, 3], data.cell[0, 0], data.cell[1, 3], data.cell[1, 1], data.cell[2, 3], data.cell[2, 2]
        position = data.particles['Position']
        ke_atom = data.particles['Kinetic Energy']
        if units == 'metal':
            ke_atom = ke_atom / 1e6
        x, y, z = position[:, 0]-xlo, position[:, 1]-ylo, position[:, 2]-zlo
        if zhi is None:
            zhi = lz
        kB = 0.001985875    # kcal/mol/K
        # Compute linear temp
        hist_count, _ = np.histogram(z, bins=bins, range=(0, zhi))
        hist_count[hist_count == 0] = 1   # Avoid division by zero
        hist_ke_atom, bin_edges = np.histogram(z, bins=bins, range=(0, zhi), weights=ke_atom)
        bin_centers = bin_edges[:-1]
        linear_temp = 2*hist_ke_atom / (3*kB*hist_count)
        data.attributes['Linear Temp'] = [bin_centers, linear_temp]
    
    pipeline = io.import_file(filename)
    if select is not None:
        pipeline.modifiers.append(ESM(expression = select))
    if invert:
        pipeline.modifiers.append(ISM())
    if delete:
        pipeline.modifiers.append(DSM())
    pipeline.modifiers.append(CPM(output_property='Kinetic Energy', expressions=['0.5 * Mass * (Velocity.X^2 + Velocity.Y^2 + Velocity.Z^2) * 2390.056761495559']))
    pipeline.modifiers.append(LinearTempModifier)
    num_frames = pipeline.source.num_frames
    if frames is None:
        frames = [0, num_frames-1]

    for i in frames:
        data = pipeline.compute(i)
        time = data.attributes['Timestep'] * dt * 1e-3   # ps
        z = data.attributes['Linear Temp'][0]
        linear_temp = data.attributes['Linear Temp'][1]
        plt.plot(z, linear_temp, label=f'{time:.2f} ps')
    plt.xlabel('Z coordinate (Å)')
    plt.ylabel('Temperature (K)')
    plt.legend()
    plt.show()

################################################################################################################
def plot_spatial_temp(filename: str = 'dump.lmp', dt: float = 0.1, frames: list = None, select: str = None, delete: bool = False, invert: bool = False, bins: int = 5):
    """
    Read dump file for spatial temperature in xy plane

    Parameters
        `file` (str): dump file name
        
        `dt` (float): time step (fs)
        
        `frames` (list): list of frames to plot
        
        `select` (str): selection expression

        `delete` (bool): delete selection
        
        `invert` (bool): invert selection
        
        `bins` (int): number of bins
        
        `zhi` (float): upper limit of z

    Returns
    """
    def SpatialTempModifier(frame, data, bins=bins):
        # Load position and mass
        xlo, lx, ylo, ly, zlo, lz = data.cell[0, 3], data.cell[0, 0], data.cell[1, 3], data.cell[1, 1], data.cell[2, 3], data.cell[2, 2]
        position = data.particles['Position']
        ke_atom = data.particles['Kinetic Energy']
        x, y, z = position[:, 0]-xlo, position[:, 1]-ylo, position[:, 2]-zlo
        range = [[0, lx], [0, ly]]
        kB = 0.001985875    # kcal/mol/K
        # Compute spatial temp
        hist_count, _, _ = np.histogram2d(x, y, bins=bins, range=range)
        hist_count[hist_count == 0] = 1  # Avoid division by zero
        hist_ke_atom, _, _ = np.histogram2d(x, y, bins=bins, range=range, weights=ke_atom)
        spatial_temp = 2*hist_ke_atom / (3*kB*hist_count)
        extent = [0, lx, 0, ly]
        data.attributes['Spatial Temp'] = [extent, spatial_temp]
    
    pipeline = io.import_file(filename)
    if select is not None:
        pipeline.modifiers.append(ESM(expression = select))
    if invert:
        pipeline.modifiers.append(ISM())
    if delete:
        pipeline.modifiers.append(DSM())
    pipeline.modifiers.append(CPM(output_property='Kinetic Energy', expressions=['0.5 * Mass * (Velocity.X^2 + Velocity.Y^2 + Velocity.Z^2) * 2390.056761495559']))
    pipeline.modifiers.append(SpatialTempModifier)
    num_frames = pipeline.source.num_frames
    if frames is None:
        frames = [0, num_frames-1]

    for i in frames:
        data = pipeline.compute(i)
        time = data.attributes['Timestep'] * dt * 1e-3   # ps
        extent = data.attributes['Spatial Temp'][0]
        spatial_temp = data.attributes['Spatial Temp'][1]
        plt.imshow(spatial_temp.T, extent=extent, origin='lower')
        plt.colorbar(label='Temperature (K)')
        plt.xlabel('X (Å)')
        plt.ylabel('Y (Å)')
        plt.title(f'Spatial temperature at {time:.2f} ps for {select}')
        plt.show()

################################################################################################################

def SpeFile(filename: str = 'species.lmp', dt: float = 0.1, delete: bool = False, times: list = None):
    """
    Read Species file and return a pandas DataFrame

    Parameters
        `file` (str): Species filename
        
        `dt` (float): time step (fs)
        
        `delete` (bool): whether atoms are deleted in the simulation

    Returns
        `spe` (DataFrame): pandas DataFrame with all species
    """
    import pandas as pd

    # Read the file
    with open(filename, 'r') as f:
        lines = f.readlines()

    # Initialize an empty dictionary to store the data
    dict = {}

    # Iterate through lines to find headers and data
    for line in lines:
        if line.startswith("#"):
            # This line contains headers
            headers = line.split()[1:]
            max_len = 0
            for key in dict.keys():
                max_len = max(max_len, len(dict[key]))
                if key not in headers:
                    dict[key].append(0)
            for header in headers:
                if header not in dict:
                    dict[header] = [0] * max_len                
        else:
            # This line contains data
            values = line.split()
            for header, value in zip(headers, values):
                dict[header].append(int(value))

    # Convert the dictionary to a pandas DataFrame
    spe = pd.DataFrame(dict)
    if times is None:
        spe['Time'] = spe['Timestep'] * dt / 1000   # ps
    else:
        spe['Time'] = times
    spe = spe[['Time'] + [col for col in spe.columns if col != 'Time']]
    
    if delete:
        # For each row in the datafram spe, add all the previous rows up to the current row to give the cumulative sum
        # Except for Time, Timestep, and No_Specs columns
        # Use column name to determine
        for col in spe.columns:
            if col not in ['Time', 'Timestep', 'No_Specs']:
                spe[col] = spe[col].cumsum()
        # Update No_Specs column by determining the number of non-zero columns excluding Time, Timestep, and No_Moles, and No_Specs columns
        spe['No_Specs'] = spe.iloc[:, 4:].astype(bool).sum(axis=1)
            
    return spe

################################################################################################################

def SmallSpeFile(filename: str = 'species.lmp', dt: float = 0.1, species: list = None, delete: bool = False, times: list = None):
    """
    Read Species file and return a pandas DataFrame

    Parameters
        `file` (str): Species filename

        `dt` (float): time step (fs)

        `species` (list): list of species to read
        
        `delete` (bool): whether atoms are deleted in the simulation

    Returns
        `spe` (DataFrame): pandas DataFrame with species of interest
    """
    import pandas as pd

    # Read the file
    with open(filename, 'r') as f:
        lines = f.readlines()

    # Initialize an empty dictionary to store the data
    if species is None:
        species = ['CO', 'CO2', 'H', 'H2', 'H2O', 'O', 'O2']
    dict = {'Timestep': [], 'No_Moles': [], 'No_Specs': []}
    for spec in species:
        dict[spec] = []

    # Iterate through lines to find headers and data
    for line in lines:
        if line.startswith("#"):
            # This line contains headers
            headers = line.split()[1:]
            for key in dict.keys():
                if key not in headers:
                    dict[key].append(0)                
        else:
            # This line contains data
            values = line.split()
            for header, value in zip(headers, values):
                if header in dict:
                    dict[header].append(int(value))

    # Convert the dictionary to a pandas DataFrame
    spe = pd.DataFrame(dict)
    if times is not None:
        spe['Time'] = times
    else:
        spe['Time'] = spe['Timestep'] * dt / 1000   # ps
    spe = spe[['Time'] + [col for col in spe.columns if col != 'Time']]
    
    if delete:
        # For each row in the datafram spe, add all the previous rows up to the current row to give the cumulative sum
        # Except for Time, Timestep, and No_Specs columns
        # Use column name to determine
        for col in spe.columns:
            if col not in ['Time', 'Timestep', 'No_Specs']:
                spe[col] = spe[col].cumsum()
        # Update No_Specs column by determining the number of non-zero columns excluding Time, Timestep, and No_Moles, and No_Specs columns
        spe['No_Specs'] = spe.iloc[:, 4:].astype(bool).sum(axis=1)
        
    return spe

################################################################################################################

def ChemReact(spe: pd.DataFrame = None, AO: bool = True, insert: bool = False):
    """
    Read a pandas DataFrame containing species data and return a list of chemical reactions
    
    Parameters
        `spe` (DataFrame): pandas DataFrame with species data
        `AO` (bool): whether to include No. of AO in the reaction equation
    
    Returns
        `reacts` (dict): dictionary of simplified chemical reactions
        `reactions` (list): list of complete chemical reactions
    """
    if insert is False:
        if AO:
            AO_num = spe.index.max()
            a = np.arange(AO_num+1) - 1
            AOs = a
            AOs = np.max(AOs) - AOs
            spe['A'] = spe['A'] + AOs
        else:
            spe['A'][0] = spe['A'][0] + 1

    # Create a list to store the chemical reactions
    reactions = []
    reacts = {}

    # Select the columns to consider for changes (excluding the first 4 columns)
    columns_to_track = spe.columns[4:]

    # Iterate through the DataFrame to calculate changes and generate reactions
    for i in range(1, len(spe)):
        previous_row = spe.iloc[i - 1]
        current_row = spe.iloc[i]
        
        # Calculate the changes in compound quantities for selected columns
        changes = current_row[columns_to_track] - previous_row[columns_to_track]
        
        # Separate changes into reactants (with minus sign) and products (with plus sign)
        reactants = []
        reactants2 = []
        products = []
        products2 = []
        for column in changes.index:
            #if re.search(r'C.*H.*N.*O', column):
                #replace = 'CnHnNnOn'
            if re.search(r'C.*H.*N', column):
                replace = 'CnHnNnOn'
            elif re.search(r'C.*H.*O', column):
                replace = 'CnHnNnOn'
            elif re.search(r'C.*N.*O', column):
                replace = 'CnHnNnOn'
            elif re.search(r'H.*N.*O', column):
                replace = 'CnHnNnOn'
            else:
                replace = column
            if changes[column] < 0:
                reactants.append(f"{-int(changes[column])} {column}")
                reactants2.append(f"{-int(changes[column])} {replace}")
            elif changes[column] > 0:
                products.append(f"{int(changes[column])} {column}")
                products2.append(f"{int(changes[column])} {replace}")         
            
        #reactants = [f"{-int(changes[column])} {column}" for column in changes.index if changes[column] < 0]
        reactants.sort(key=lambda x: x.split(' ')[1])   # Sort by reactant name
        reactants2.sort(key=lambda x: x.split(' ')[1])   # Sort by reactant name
        
        #products = [f"{int(changes[column])} {column}" for column in changes.index if changes[column] > 0]
        products.sort(key=lambda x: x.split(' ')[1])
        products2.sort(key=lambda x: x.split(' ')[1])
        
        # combine same reactant names
        reactants2 = [f"{sum([int(i.split(' ')[0]) for i in reactants2 if i.split(' ')[1] == j])} {j}" for j in set([i.split(' ')[1] for i in reactants2])]
        products2 = [f"{sum([int(i.split(' ')[0]) for i in products2 if i.split(' ')[1] == j])} {j}" for j in set([i.split(' ')[1] for i in products2])]
        
        # Change all coefficient to 1 for reactants2 and products2
        reactants2 = [f"{i.split(' ')[1]}" for i in reactants2]
        products2 = [f"{i.split(' ')[1]}" for i in products2]
        
        # Create the reaction equation
        if len(reactants) != 0 or len(products) != 0:
            if AO:
                reaction_text = f"AO = {i}, Time = {current_row['Time']} ps: " + " + ".join(reactants) + " -> " + " + ".join(products)
            else:
                reaction_text = f"Time = {current_row['Time']} ps: " + " + ".join(reactants) + " -> " + " + ".join(products)
            react_text = " + ".join(reactants2) + " -> " + " + ".join(products2)
            reactions.append(reaction_text)
            if react_text not in reacts.keys():
                reacts[react_text] = 1
            else:
                reacts[react_text] += 1

    reacts = sorted(reacts.items(), key=lambda x: x[1], reverse=True)
    return reacts, reactions