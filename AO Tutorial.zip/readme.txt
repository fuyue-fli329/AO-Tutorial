We will use Jupyter Notebook for the tutorial.
Please download Visual Studio Code (https://code.visualstudio.com/) to open the ".ipynb" file.

There are three parts:
1. Introduction. We will prepare for the simulation with some background information and software installation.
2. LAMMPS. We will dive into the simulation by conducting the atomic carbon bombardment for polyethylene.
3. "lammps_tools.py". This is a python script containing useful function for post-analysis. You can refer this if needed.


Please read "Introduction.ipynb" before opening the "LAMMPS" folder.